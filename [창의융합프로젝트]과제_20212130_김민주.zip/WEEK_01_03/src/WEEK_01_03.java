class Animal{
	String name;
}

class Dog extends Animal{//Animal 클래스 상속받는다
}

public class WEEK_01_03 {
	public static void main(String[] args) {
		Dog dog =new Dog();
		dog.name="해피";
		System.out.println(dog.name);
	}

}
