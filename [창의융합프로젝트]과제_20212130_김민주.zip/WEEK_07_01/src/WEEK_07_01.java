class Calculation {
	int z;
	public void addition(int x, int y) {
		z=x+y;
		System.out.println("두 수의 덧셈:"+z);
	}
	public void substraction(int x, int y) {
		z=x-y;
		System.out.println("두 수의 뺼셈:"+z);
	}
}
public class WEEK_07_01 extends Calculation{
	public void multiplication(int x, int y) {
		z=x*y;
		System.out.println("두 수의 곱셈:"+z);
	}
	public static void main(String[] args) {
		int a =20, b=10;
		WEEK_07_01 obj=new WEEK_07_01();
		obj.addition(a, b);
		obj.substraction(a, b);
		obj.multiplication(a, b);
	}
}
