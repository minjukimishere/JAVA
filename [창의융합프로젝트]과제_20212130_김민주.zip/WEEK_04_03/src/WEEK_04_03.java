class Box{
	private int width, height, depth;
	public Box() {
		this(1,1,1);
		System.out.println("0");
	}
	public Box(int width) {
		this(width,1,1);
		System.out.println("1");
	}
	public Box(int width, int height) {
		this(width,height,1);
		System.out.println("2");
	}
	public Box(int width, int height, int depth) {
		this.width=width; this.height=height; this.depth=depth;
		System.out.print("3\t");
	}
	public int getVolume() {
		return width*height*depth;
	}
	
}
public class WEEK_04_03 {
	public static void main(String[] args) {
		Box _Box =new Box();
		System.out.println("매개변수입력없음"+_Box.getVolume());
		_Box=new Box(10);
		System.out.println("매개변수한개입력"+_Box.getVolume());
		_Box=new Box(10,20);
		System.out.println("매개변수두개입력"+_Box.getVolume());
		_Box=new Box(10,20,30);
		System.out.println("매개변수세개입력"+_Box.getVolume());
	}
}
