//Chapter003 상속2
//01 메소드 오버라이딩 02 예약어 super
//같은 클래스에 있는 것은 오버로딩 - 예약어 this
//부모가 가지고 있는 것에 대해 똑같이 상속할 땐 오버라이딩 = 예약어 super
//상속 관계에 있는 클래스들 간에 같은 이름의 메소드를 정의하는 경우
// 상위 클래스의 메소드와 하위 클래스의 메소드가 [메소드 이름, 매개변수의 타입,개수 같아야 함]
//치환: 상위 클래스의 메소드를 하위 클래스의 메소드로 교체
class Overriding{
	public void show(String str) {
		System.out.println("상위 클래스의 메소드 show(String str) 수행");
		System.out.println(str+"/n");
	}
}
class Overriding_child extends Overriding{
	public void show() {
		System.out.println("하위 클래스의 메소드 show()수행");
	}
}
public class WEEK_08_01 {
	public static void main(String[] args) {
		Overriding_child _Overriding_child=new Overriding_child();
		//new: 객체 생성 키워드 [클래스이름 객체이름 = new 클래스이름();]
		//해당 클래스에 인스턴스를 생성하여 객체이름의 변수를 할당한다
		_Overriding_child.show("원광대학교 창의융합프로젝트");
		_Overriding_child.show();
	}
}
