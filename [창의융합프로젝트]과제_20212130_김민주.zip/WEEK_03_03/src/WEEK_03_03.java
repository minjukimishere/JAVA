class FinalizerDemo{
	private int nIndex;
	//오버라이딩
	protected void fianlize() throws Throwable{
		System.out.println(nIndex+"번째 Clean up");
	}
	public void hello(int index) {
		nIndex=index;
		System.out.println(index+"번쨰 hello");
	}
	
}
public class WEEK_03_03 {
	public static void main(String[] args) {
		new WEEK_03_03().run();
	}
	private void run() {
		for (int i=0; i<100; i++) {//몇 번을 돌려야 cleanup이 나오나
			FinalizerDemo finalizerDemo =new FinalizerDemo();
			finalizerDemo.hello(i);
			//System.gc();
		}
	}

}
