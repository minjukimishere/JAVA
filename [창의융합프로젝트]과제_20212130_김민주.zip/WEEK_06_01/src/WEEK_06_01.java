	class Subject{
		private int score;
		private String name;
		private int min=0;
		private int max=1000;
		
		public Subject(){
			
		}
		public Subject(String name) {
			this.name=name;
		}
		public Subject(String name,int score) {
			this.name=name;
			this.score=score;
		}
		public int getScore() {
			return score;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name=name;
		}
		public boolean isValid() {
			if(this.score>=this.min&&this.score<=this.max) {
				return true;
			}else {
				return false;
			}
		}
		public char getGrade() {
			if(this.score>=max-(max/10)&&this.score<=max) {
				return 'A';
			}
			else if(this.score>=max-(2*max/10)&&this.score<=max) {
				return 'B';
			}
			else if(this.score>=max-(3*max/10)&&this.score<=max) {
					return 'C';
			}
			else if(this.score>=max-(4*max/10)&&this.score<=max) {
				return 'D';
			}else {
				return 'F';
			}
		}
		public void setRangeScore(int i,int j) {
			this.min=i; this.max=j;
			double dscore;
			dscore=(double)this.score*((double)j/100);
			this.score=(int) dscore;
		}
		public int[] getRangeScore() {
			int arr[] = new int[this.max-this.min];
			int count=this.min;
			for(int i=0; i<arr.length; i++) {
				arr[i]=count++;
			}
			return arr;
		}
		public boolean equalSubject(Subject _Subject) {
			if(this.name.equals(_Subject.name)) {
				return true;
			}else {
				return false;
			}
		}
		public boolean gt(Subject _Subject) {
			if(this.score> _Subject.score) {
				return true;
			}else {
				return false;
			}
		}
		public boolean ge(Subject _Subject) {
			if(this.score>= _Subject.score) {
				return true;
			}else {
				return false;
			}
		}
		public boolean lt(Subject _Subject) {
			if(this.score< _Subject.score) {
				return true;
			}else {
				return false;
			}
		}
		public boolean le(Subject _Subject) {
			if(this.score<=_Subject.score) {
				return true;
			}else {
				return false;
			}
		}
		public boolean eq(Subject _Subject) {
			if(this.score==_Subject.score) {
				return true;
			}else {
				return false;
			}
		}
		public boolean nq(Subject _Subject) {
			if(this.score!=_Subject.score) {
				return true;
			}else {
				return false;
			}
		}
		public void setScore(int score) {
			if(this.score<this.min|this.score>this.max) {
				this.score=-1;
			}else {
				this.score=score;
			}
		}
		
		
	}

public class WEEK_06_01 {
	public static void main(String[] args) {
		Subject sub1=new Subject();
		Subject sub2=new Subject("운영체제");
		Subject sub3=new Subject("알고리즘",88);
		
		sub1.setName("창의융합프로젝트");
		sub1.setScore(71);
		
		if(sub1.isValid()) {
			System.out.println("점수가 유효합니다.");
		}else {
			System.out.println("점수가 유효하지 않습니다.");
		}
		System.out.println(sub1.getGrade());
		sub1.setRangeScore(0,10);
		int[] rg=sub1.getRangeScore();
		if(sub1.equalSubject(sub2)) {
			System.out.println("동일한 과목 입니다.");
		}else {
			System.out.println("동일한 과목이 아닙니다.");
		}
		if(sub1.gt(sub2)) {
			System.out.println(sub1.getName()+"의 점수가 더 높습니다.");
		}
	}
}
