class Super{
	int x=1000;
	void display() {
		System.out.println("상위클래스 Super의 display 메소드");
	}
}
class Super_child extends Super{
	int x=2000;
	void display() {
		System.out.println("하위 클래스 Super_child의 display메소드");
	}
	void write() {
		display();
		super.display();
		System.out.println("Super_child 클래스 객체의 x값은:"+x);
		System.out.println("Super 클래스 객체의 x값은:"+super.x);
	}
}
public class WEEK_08_05 {
	public static void main(String[] args) {
		Super_child _Super_child=new Super_child();
		_Super_child.write();
	}
}
