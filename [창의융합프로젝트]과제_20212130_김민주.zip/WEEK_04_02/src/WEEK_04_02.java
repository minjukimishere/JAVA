class Box{
	public int nwidth, nheight, ndepth;
	public double dwidth, dheight, ddepth;
	public Box(int w,int h,int d) {
		nwidth=w; nheight=h; ddepth=d;
	}
	public Box(double w,double h, double d) {
		dwidth=w; dheight=h; ddepth=d;
	}
}
public class WEEK_04_02 {
	public static void main(String[] args) {
		Box _Box =new Box(10,20,30);//3개의 정수 매개변수 생성자 수행
		int nvol=_Box.nwidth*_Box.nheight*_Box.ndepth;
		System.out.println("박스의 부피(정수 매개변수):"+nvol);
		_Box=new Box(10,20,30.5);//3개의 실수 매개변수 생성자 수행
		double dvol=_Box.dwidth*_Box.dheight*_Box.ddepth;
		System.out.println("박스의 부피(실수 매개변수):"+dvol);
		_Box=new Box(10,20,30.5);
		
		System.out.print("nwidth:"+_Box.nwidth);
		System.out.print(",nheight:"+_Box.nheight);
		System.out.print(",ndepth:"+_Box.ndepth);
		
		System.out.print("dwidth:"+_Box.dwidth);
		System.out.print(",dheight:"+_Box.dheight);
		System.out.print(",ddepth:"+_Box.ddepth);
		
		dvol=_Box.dwidth*_Box.dheight*_Box.ddepth;
		System.out.println("박스의 부피(정수와 실수 혼합 매개변수):"+dvol);
	}
}
