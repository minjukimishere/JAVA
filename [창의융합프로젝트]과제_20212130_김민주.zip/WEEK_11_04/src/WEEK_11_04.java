public class WEEK_11_04 {
 public static void main(String[] args) throws InterruptedException {
		System.out.println("스레드시작");
	new Thread(()->{
		for (int i=0; i<5; i++)
			System.out.println(i);
	}).start(); 
	Thread.sleep(500);
	System.out.println("스레드끝");
 }
}
