class check{
	private int checkNum;
	public check(int Num) {//명시적 생성자
		checkNum=Num;
	}          // 오버로딩: 같은 기능을 하는 메소드를 하나의 이름으로 사용 가능
	@Override //오버라이딩:상속받은 메소드 재정의
	protected void finalize() throws Throwable{ //패키지 내 사용
		//소멸자 예외처리 throws Throwable
		System.out.println(checkNum+"에 있는 finalize() 실행");
	}
}
public class WEEK_03_02 {
	public static void main(String[] args) {
		for(int i=0; i<20; i++) {
			check test=new check(i);
			
			test=null; //null값을 넣어 기존에 있는 값을 쓰레기로 만듬
			System.gc(); //가비지 컬렉터 실행
		}
	}
}
