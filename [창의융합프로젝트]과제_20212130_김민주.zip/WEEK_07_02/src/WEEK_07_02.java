import java.util.Scanner;

class Ramyon{
	String ramyon="라면";
	String water="물";
	String onion="파";
	void boilwater() {
		System.out.println(water+"을 끓인다.");
	}
	void cooking() {
		System.out.println(ramyon+"과"+onion+"를 넣고 끓여요리 완성");
		System.out.println("맛있게 드세요!!!");
	}
}
class RiceRamyon extends Ramyon{
	String topp="떡";
	void topping() {
		System.out.println(topp+"을 넣는다.");
	}
}
class CheeseRamyon extends Ramyon{
	String topp="치즈";
	void topping() {
		System.out.println(topp+"를 넣는다.");
	}
}
public class WEEK_07_02 {
 public static void main(String[] args) {
	int index=0;
	do {
		System.out.println("만들고 싶은 라면을 선택하시오");
		System.out.println("1.일반2.떡3.치즈99.종료");
		Scanner _Scanner=new Scanner(System.in);
		index=_Scanner.nextInt();
		
		switch(index) {
		case 1:
			Ramyon _Ramyon=new Ramyon();
			_Ramyon.boilwater();
			_Ramyon.cooking();
			break;
		case 2:
			RiceRamyon _RiceRamyon=new RiceRamyon();
			_RiceRamyon.boilwater();
			_RiceRamyon.cooking();
			break;
		case 3:
			CheeseRamyon _CheeseRamyon=new CheeseRamyon();
			_CheeseRamyon.boilwater();
			_CheeseRamyon.cooking();
			break;
		}
	}while(index !=99);
	System.out.println("감사합니다.");
 }
}
