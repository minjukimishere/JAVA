class Calculator {
  void cal(char c, int ...num) {
    if (num.length < 2) {
      System.out.println("최소한 데이터가 2개 이상 입력 되어야 함");
      return;
    }
    int result = num[0];
    for (int i = 1; i < num.length; i++) {
      switch (c) {
        case '+':
          result += num[i];
          break;
        case '-':
          result -= num[i];
          break;
        case '*':
          result *= num[i];
          break;
        case '/':
          result /= num[i];
          break;
      }
    }

    System.out.println(result);
  }
}
public class WEEK_05_02 {
  public static void main(String[] args) {
    Calculator _Calculator = new Calculator();
    _Calculator.cal('+', 2, 3);
    _Calculator.cal('+', 2, 3, 5);
    _Calculator.cal('+', 2, 3, 5, 10);

    _Calculator.cal('-', 10, 2);
    _Calculator.cal('-', 10, 2, 3);
    _Calculator.cal('-', 10, 2, 3, 5);

    _Calculator.cal('*', 10, 2);
    _Calculator.cal('*', 10, 2, 3);

    _Calculator.cal('/', 10, 2);
    _Calculator.cal('/', 10, 2, 3);
  }
}
