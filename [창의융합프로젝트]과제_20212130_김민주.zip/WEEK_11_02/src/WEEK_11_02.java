class Runnable_A implements Runnable{ //멀티스레딩
	public void run() {
		for (int i=0; i<5; i++)
			System.out.println(i);
	}
}
public class WEEK_11_02 {
 public static void main(String[] args) throws InterruptedException {
	Thread _Thread=new Thread(new Runnable_A()); 
	System.out.println("스레드시작");
	_Thread.start();
	_Thread.join();
	//join:스레드종료대기,slepp:sleeptiem종료대기,wait:notify신호기다림
	System.out.println("스레드끝");
 }
}
