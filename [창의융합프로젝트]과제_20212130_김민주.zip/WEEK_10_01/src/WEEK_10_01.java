abstract class Animal{
	public abstract void printSound();
	public void displayInfo() {
		System.out.println("나는 동물입니다");
	}
}

class Cat extends Animal{
	public void printSound() {
		System.out.println("고양이는 야옹야옹");
	}
}

public class WEEK_10_01 {
	public static void main(String[] args) {
			Cat myCat=new Cat();
			myCat.printSound();
			myCat.displayInfo();
	}
}