class Am{
	int count=1;
	void callme() {
		System.out.println("Am의 callme 실행, count값:+count");
	}
}
class Bm extends Am{
	int count=2;
	void callme() {
		System.out.println("Bm의 callme 실행, count값:+count");
	}	
}
class Cm extends Am{
	int count=3;
	void callme() {
		System.out.println("Bm의 callme 실행, count값:+count");
	}	
}
public class WEEK_09_04 {
	public static void main(String[] args){
		Am _Am=new Am();
		_Am.callme();
		System.out.println("_Am.count 값:"+_Am.count);
		_Am=new Bm();
		_Am.callme();
		System.out.println("_Am.count의 값:"+_Am.count);
	}
}
