class Box{
	private int width, height, depth;
	public Box() {
		width=height=depth=1;
	}
	public Box(int w) {
		width =w; height=depth=1;
	}
	public Box(int w,int h) {
		width =w; height=h; depth=1;
	}
	public Box(int w,int h,int d) {
			width =w; height=h; depth=d;
	}
	public int getVolume() {
		return width*height*depth;
	}
}
public class WEEK_04_01 {
	public static void main(String[] args) {
		Box _Box= new Box();
		System.out.println("매개변수를 입력하지 않은 박스의 부피:"+_Box.getVolume());
		_Box=new Box(10);
		System.out.println("매개변수를 1개만 입력 한 박스의 부피:"+_Box.getVolume());
		_Box=new Box(10,20);
		System.out.println("매개변수를 2개만 입력 한 박스의 부피:"+_Box.getVolume());
		_Box=new Box(10,20,30);
		System.out.println("매개변수를 3개만 입력 한 박스의 부피:"+_Box.getVolume());
	}
}
