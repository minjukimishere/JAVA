class Animal{
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name=name;
	}//매개변수 String name 인스턴스 변수 name
}

class Dog extends Animal{
}

public class WEEK_02_01 {
	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.setName("해피");
		System.out.println(dog.getName());
	}
}
