class Thread_A extends Thread{
	public void run() {
		for (int i=0; i<5; i++)
			System.out.println(i);
	}
}
public class WEEK_11_01 {
	public static void main(String[] args) throws InterruptedException{
		Thread_A thread1=new Thread_A();
		System.out.println("스레드시작");
		thread1.start();
		System.out.println("스레드끝");
	}
}

