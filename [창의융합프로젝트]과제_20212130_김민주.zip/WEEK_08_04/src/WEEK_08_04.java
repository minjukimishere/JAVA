class Super{
	public int x=500;
	public int y=1000;
}
class Super_child extends Super{
	public String x="원광대학교 창의융합프로젝트";
	public String xx=x+super.x;
	public String yy=""+y+super.y;
}
public class WEEK_08_04 {
	public static void main(String[] args) {
		Super_child _Super_child=new Super_child();
		System.out.println("객체sb2에들은x,y,값:"+_Super_child.x+_Super_child.y);
		System.out.println("객체sb2에들은xx값:"+_Super_child.xx);
		System.out.println("객체sb2에들은yy값:"+_Super_child.yy);
	}
}
