abstract class Vehicle{abstract void printPrice();}
abstract class TwoWheeler extends Vehicle{abstract void printPrice();}
abstract class FourWheeler extends Vehicle{}
class Bike extends TwoWheeler{
	public void printPrice() {System.out.println("가격:150,000");}
	public void printType() {System.out.println("이것은 자전거입니다.");}
	public void printBrand() {System.out.println("브랜드: 삼천리");}
}
class Car extends FourWheeler{
	public void printPrice() {System.out.println("가격:50,000,000");}
	public void printType() {System.out.println("이것은 자동차입니다.");}
	public void printBrand() {System.out.println("브랜드: BMW");}
}

public class WEEK_10_02 {
	public static void main(String[] args) {
		Bike myBike=new Bike();
		Car myCar=new Car();
		myBike.printType();
		myBike.printBrand();
		myBike.printPrice();
		System.out.println("-----------------");
		myCar.printType();
		myCar.printBrand();
		myCar.printPrice();
	}
}
