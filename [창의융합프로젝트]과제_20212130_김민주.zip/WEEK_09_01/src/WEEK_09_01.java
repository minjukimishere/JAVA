class Rectangle{
	public int width;
	public int height;
	public Rectangle(int width, int height) {
		this.width=width;
		this.height=height;
	}
	public int computeRectangleArea() {
		return width*height;
	}
}
class Cube extends Rectangle{
	public int depth;
	public Cube(int width, int height,int depth) {
		super(width,height);
		this.depth=depth;
	}
	public int computeCubeArea() {
		return super.computeRectangleArea()*depth;
	}
}
public class WEEK_09_01 {
	public static void main(String[] args) {
		Rectangle _Rectangle=new Cube(10,20,30);
		System.out.println("넓이는:"+_Rectangle.computeRectangleArea());
	}

}
