class Animal {
	String name;
}

public class WEEK_01_02 {
	public static void main(String[] args) {
		Animal cat =new Animal(); // Animal의 객체 cat 생성
		cat.name="나비";
		
		Animal dog=new Animal();
		dog.name="해피";
		
		System.out.println(cat.name);//객체변수 name 사용
		System.out.println(dog.name);//
	}
}
