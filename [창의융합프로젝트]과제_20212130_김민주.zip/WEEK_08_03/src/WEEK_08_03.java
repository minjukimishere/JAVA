class Overriding{
	public void show(String str) {
		System.out.println("상위 클래스의 메소드 show(String str)수행");
		System.out.println(str+"\n");
	}
}
class Overriding_child extends Overriding{
	@Override
	public void shaw(String str) {
		System.out.println("하위 클래스의 메소드 show(String str) 수행");
		System.out.println(str+"\n");
	}
}
public class WEEK_08_03 {
	public static void main(String[] args) {
		Overriding_child _Overriding_child=new Overriding_child();
		_Overriding_child.show("원광대학교 창의융합프로젝트");
	}
}
