class Overriding{
	public void show(String str) {
		System.out.println("상위 클래스의 메소드 show(String str) 수행");
	}
}

public class WEEK_08_02 {

}
