class Rectangle{
	public int width;
	public int height;
	public Rectangle(int width, int height) {
		this.width=width;
		this.height=height;
	}
	public int computeRectangleArea() {
		return width*height;
	}
}
class Cube extends Rectangle{
	public int depth;
	public Cube(int width, int height, int depth) {
		super(width,height);
		this.depth=depth;
	}
	public int ComputeCubeArea() {
		return super.computeRectangleArea()*depth;
	}
}

public class WEEK_09_03 {
	public static void main(String[] args) {
		Rectangle _Rectangle=new Rectangle(10,20);
		Cube _Cube=new Cube(10,20,30);
		System.out.println("사각형이사각형의객체?"+(_Rectangle instanceof Rectangle));
		System.out.println("사각형이큐브의객체?"+(_Rectangle instanceof Cube));
		System.out.println("큐브가사각형의객체?"+(_Cube instanceof Rectangle));
		System.out.println("큐브가큐브의객체?"+(_Cube instanceof Cube));
		System.out.println("형변환이후");
		_Rectangle=new Cube(20,30,40);
		System.out.println("형변환사각형이사각형의객체?"+(_Rectangle instanceof Rectangle));
		System.out.println("형변환사각형이큐브의객체?"+(_Rectangle instanceof Cube));
		System.out.println("형변환큐브가사각형의객체?"+(_Cube instanceof Rectangle));
		System.out.println("형변환큐브가큐브의객체?"+(_Cube instanceof Cube));
		System.out.println("====");
		System.out.println("형변환큐브가Object의객체?"+(_Cube instanceof Object));
}
}