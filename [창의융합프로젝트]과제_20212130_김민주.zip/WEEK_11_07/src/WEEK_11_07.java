class Thread_A extends Thread{
	public Thread_A(String name) {
		setName(name);
	}
	public void run() {
		for (int i=0; i<5; i++) {
			System.out.println(getName()+"->");
			try {
				sleep(100);
			}catch(InterruptedException e) {
			}
		}
	}
}
public class WEEK_11_07 {
	public static void main(String[] args) {
		Thread_A t1=new Thread_A("느긋한");
		t1.setPriority(Thread.MIN_PRIORITY);
		Thread_A t2=new Thread_A("급한");
		t2.setPriority(Thread.MAX_PRIORITY);
		t1.start();
		t2.start();
		}
	}