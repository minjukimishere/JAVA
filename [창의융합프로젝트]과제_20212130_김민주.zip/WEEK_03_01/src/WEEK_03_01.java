class Box{ 
	private int width;
	private int height;
	private int depth;
	
	public Box() {
		width=depth=height=1;
	}
	
	public Box(int w, int h, int d) {
		width=w;
		height=h;
		depth=d;
	}

	public int getVolume() {
		return width*height*depth;
	}
}
public class WEEK_03_01{
	public static void main(String[] args) {
		Box mybox=new Box();
		System.out.println("박스의 부피는:" +mybox.getVolume());
		mybox=new Box(10,20,30);
		System.out.println("박스의 부피는:"+mybox.getVolume());
	}
}