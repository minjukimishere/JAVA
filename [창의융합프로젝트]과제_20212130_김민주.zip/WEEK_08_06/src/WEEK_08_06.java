class Super{
	public int i1;
	public double d1;
	public Super(int i1) {
		System.out.println("Super(int i1) 생성자 수행");
		this.i1=i1*i1;
		System.out.println(i1+"의 2제곱은:"+this.i1);
	}
	public Super(double d1) {
		System.out.println("Super(double d1) 생성자 수행");
		this.d1=d1*d1;
		System.out.println(d1+"의 2제곱은:"+this.d1);
	}
}
class Super_child extends Super{
	public Super_child(int i1) {
		super(i1);
		System.out.println("Super_child(int i1) 생성자 수행");
		this.i1=this.i1*i1;
		System.out.println(i1+"의 3제곱은:"+this.i1);
	}
	public Super_child(double d1) {
		super(d1);
		System.out.println("Super_child(double d1)생성자수행");
		this.d1=this.d1*d1;
		System.out.println(d1+"의 3제곱은:"+this.d1);
	}
}
public class WEEK_08_06 {
	public static void main(String[] args) {
		Super_child sub1=new Super_child(10);
		Super_child sub2=new Super_child(10.5);
	}
}
