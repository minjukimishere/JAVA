class Calculator {
	float result=1;
	
	float add(float num) { 
		result +=num; 
		return result; 
	}
	float sub(float num) { 
		result -=num; 
		return result; 
	}
	float mul(float num) { 
		result *=num; 
		return result; 
	}
	float div(float num) { 
		result /=num; 
		return result; 
	}
}

public class WEEK_01_01 {
	public static void main(String[] args) {
		Calculator cal1 = new Calculator(); //계산기1 객체생성
		Calculator cal2 = new Calculator();//계산기2 객체생성
		
		System.out.println(cal1.mul(8));
		System.out.println(cal1.mul(2));
		
		System.out.println(cal2.div(8));
		System.out.println(cal2.div(2));
	}
}
