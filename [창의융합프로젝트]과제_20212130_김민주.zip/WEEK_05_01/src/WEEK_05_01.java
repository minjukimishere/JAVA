/*class Overloading{
	void something() {
		System.out.println("something!");
	}
	void something(int i) {
		System.out.println(i);
	}
	void something(int i, int i2) {
		System.out.println(i+i2);
	}
	void something(int i, double d) {
		System.out.println(i+d);
	}
}*/
class Overloading{
	int add(int first, int second) {
		return first+second;
	}
	double add(int first,double second) {
		return first+second;
	}
	double add(double first, double second) {
		return first+second;
	}
}
public class WEEK_05_01 {
	public static void main(String[] args) {
		Overloading _Overloading=new Overloading();
		_Overloading.add(10,10);
		_Overloading.add(10,10.0);
		_Overloading.add(10.0,10.0);
	}
}
